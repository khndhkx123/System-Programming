#include "hybrid.h"

unsigned long long default_try = 0;
void hybrid_lock_init(hybrid_lock * lock)
{
    pthread_mutex_init(&(lock->mlock), NULL);
    pthread_spin_init(&(lock->slock), 0);
}

void hybrid_lock_destroy(hybrid_lock * lock)
{
    pthread_mutex_destroy(&(lock->mlock));
    pthread_spin_destroy(&(lock->slock));
}

void hybrid_lock_lock(hybrid_lock * lock)
{
    struct timeval startT, endT;
    double Timeuse;
    unsigned long long try_count = 0;

    gettimeofday(&startT, NULL);
    while(!gettimeofday(&endT, NULL) && 
        (Timeuse = 1000000*((endT.tv_sec - startT.tv_sec) + (endT.tv_usec - startT.tv_usec)) < 1000000)){
        if(pthread_spin_trylock(&(lock->slock)) == 0) {
            if(pthread_mutex_trylock(&(lock->mlock)) != 0) {
                pthread_spin_unlock(&(lock->slock));
                continue;
            }
            return;
        }
    }
    pthread_mutex_lock(&(lock->mlock));
    pthread_spin_lock(&(lock->slock));
}

void hybrid_lock_unlock(hybrid_lock * lock)
{
    pthread_mutex_unlock(&(lock->mlock));
    pthread_spin_unlock(&(lock->slock));
}
