#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

typedef struct hybrid_lock {
	pthread_mutex_t mlock;
	pthread_spinlock_t slock;
}hybrid_lock;

void hybrid_lock_init(hybrid_lock * lock);
void hybrid_lock_destroy(hybrid_lock * lock);
void hybrid_lock_lock(hybrid_lock * lock);
void hybrid_lock_unlock(hybrid_lock * lock);

